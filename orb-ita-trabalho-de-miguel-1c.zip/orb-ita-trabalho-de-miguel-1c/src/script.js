document.addEventListener('DOMContentLoaded', () => {
  const btnTema = document.getElementById('btnTema');
  const btnAumentar = document.getElementById('btnAumentarFonte');
  const btnDiminuir = document.getElementById('btnDiminuirFonte');
  const btnCalcular = document.getElementById('btnCalcular');
  const inputHoras = document.getElementById('horasLuz');
  const divResultado = document.getElementById('resultado');
  const textoResultado = document.getElementById('textoResultado');

  let tamanhoFonte = 16;

  // Aumentar / Diminuir Fonte
  if (btnAumentar && btnDiminuir) {
    btnAumentar.addEventListener('click', () => {
      if (tamanhoFonte < 26) {
        tamanhoFonte += 2;
        document.documentElement.style.fontSize = `${tamanhoFonte}px`;
      }
    });

    btnDiminuir.addEventListener('click', () => {
      if (tamanhoFonte > 12) {
        tamanhoFonte -= 2;
        document.documentElement.style.fontSize = `${tamanhoFonte}px`;
      }
    });
  }

  // Alternar Modo Claro / Escuro
  if (btnTema) {
    btnTema.addEventListener('click', () => {
      document.body.classList.toggle('light-mode');
      btnTema.textContent = document.body.classList.contains('light-mode')
        ? 'Modo Claro'
        : 'Modo Escuro';
    });
  }

  // Lógica do Simulador da Luz
  // Velocidade da luz ≈ 1.0792528488 × 10^9 km/h
  const VELOCIDADE_LUZ_KM_H = 1079252848.8;

  if (btnCalcular) {
    btnCalcular.addEventListener('click', () => {
      const horas = parseFloat(inputHoras.value);

      if (isNaN(horas) || horas <= 0) {
        alert('Por favor, digite um valor válido de horas (maior que zero).');
        return;
      }

      const distanciaKm = horas * VELOCIDADE_LUZ_KM_H;

      // Formatação inteligente com notação científica quando necessário
      let distanciaFormatada;
      if (distanciaKm >= 1e12) {
        distanciaFormatada = distanciaKm.toExponential(3).replace('e+', ' × 10^');
      } else if (distanciaKm >= 1e9) {
        distanciaFormatada = (distanciaKm / 1e9).toFixed(3) + ' bilhões';
      } else if (distanciaKm >= 1e6) {
        distanciaFormatada = (distanciaKm / 1e6).toFixed(2) + ' milhões';
      } else {
        distanciaFormatada = distanciaKm.toLocaleString('pt-BR', { maximumFractionDigits: 0 });
      }

      // Exemplos de referência
      const voltasTerra = Math.round(distanciaKm / 40075); // circunferência aproximada da Terra
      const distanciaLua = (distanciaKm / 384400).toFixed(1);

      textoResultado.innerHTML = `
        Em <strong>${horas} hora(s)</strong>, a luz percorre aproximadamente 
        <strong>${distanciaFormatada} km</strong>.<br><br>
        Isso equivale a cerca de <strong>${voltasTerra.toLocaleString('pt-BR')}</strong> voltas ao redor da Terra 
        ou <strong>${distanciaLua}</strong> vezes a distância até a Lua.
      `;

      divResultado.classList.remove('hidden');
    });
  }
});